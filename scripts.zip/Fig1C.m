clear;clc;%close all

figure
fs=200;
t=1/fs:1/fs:.5;t=t';y1=[t;]/.5;
t=1/fs:1/fs:.75;t=t';z1=[t;]/.75;
t=1/fs:1/fs:1;t=t';
x1=zeros(fs*0.25,1);

x1s=[z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;];
y1s=[y1;y1*0;y1;y1*0;y1;y1*0;y1;y1*0;y1;y1*0;y1;y1*0;y1;y1*0;y1;y1*0;y1;y1*0;y1;y1*0;];
t=1/fs:1/fs:10;
subplot 523;hold on;plot([.75 .75],[0 1],'k:','linewidth',1.5);plot([.5 .5],[0 1],':','color',[.3 .6 1],'linewidth',1.5);xlim([0 4])
plot(t,x1s,'k','linewidth',2)
hold on;plot(t,y1s,':','color',[.3 .6 1],'linewidth',2)

f=1:size(x1s,1);f=f-1;f=f/size(x1s,1);f=f*fs;

fxs=fft(x1s);ttp=abs(fxs)/10;%ttp=20*log10(ttp+1e-10);
subplot 524;;hold on;plot([4/3 4/3],[0 100],'k:','linewidth',1.5);plot([2 2],[0 100],':','color',[.3 .6 1],'linewidth',1.5)
plot(f,ttp,'k.-','linewidth',2,'markersize',16);
fxs=fft(y1s);ttp=abs(fxs)/10;%ttp=20*log10(ttp+1e-10);
hold on;plot(f,ttp,'.:','color',[.3 .6 1],'linewidth',2,'markersize',16)
xlim(([0.15 3.5]));ylim([0 50])
set(gca,'ytick',[0 50]);set(gca,'yticklabel',['0';'1'])
set(gca,'xtick',[0:5])

x1=[x1;zeros(fs/5,1)];
y1=[y1;zeros(fs/10,1)];
x1s=[z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;];
y1s=[y1;y1*0;y1;y1*0;y1;y1*0;y1;y1*0;y1;y1*0;y1;y1*0;y1;y1*0;y1;y1*0;y1;y1*0;y1;y1*0;];
t=1/fs:1/fs:12;
subplot 525;hold on;plot([.75 .75],[0 1],'k:','linewidth',1.5);plot([.5 .5],[0 1],':','color',[.3 .6 1],'linewidth',1.5);xlim([0 4])
plot(t,x1s,'k','linewidth',2)
hold on;plot(t,y1s,':','color',[.3 .6 1],'linewidth',2)

f=1:size(x1s,1);f=f-1;f=f/size(x1s,1);f=f*fs;

fxs=fft(x1s);ttp=abs(fxs)/10;%ttp=20*log10(ttp+1e-10);
subplot 526;;hold on;plot([4/3 4/3],[0 100],'k:','linewidth',1.5);plot([2 2],[0 100],':','color',[.3 .6 1],'linewidth',1.5)
plot(f,ttp,'k.-','linewidth',2,'markersize',16);
fxs=fft(y1s);ttp=abs(fxs)/10;%ttp=20*log10(ttp+1e-10);
hold on;plot(f,ttp,'.:','color',[.3 .6 1],'linewidth',2,'markersize',16)
xlim(([0.15 3.5]));ylim([0 50])
set(gca,'ytick',[0 50]);set(gca,'yticklabel',['0';'1'])
set(gca,'xtick',[0:5])

%%
t=1/fs:1/fs:.75;t=t';z1=[t]/.75;
t=1/fs:1/fs:.5;t=t';y1=[t]/.5;
x1=[];
y1=[y1;];
x1s=[z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;z1;x1*0;];
y1s=[y1;y1*1;y1;y1*1;y1;y1*1;y1;y1*1;y1;y1*1;y1;y1*1;y1;y1*1;y1;y1*1;y1;y1*1;y1;y1*1;];
t=1/fs:1/fs:12;
subplot 527;hold on;plot([.75 .75],[0 1],'k:','linewidth',1.5);plot([.5 .5],[0 1],':','color',[.3 .6 1],'linewidth',1.5);xlim([0 4])
plot(t(1:length(x1s)),x1s,'k','linewidth',2)
hold on;plot(t(1:length(y1s)),y1s,':','color',[.3 .6 1],'linewidth',2)


f=1:size(x1s,1);f=f-1;f=f/size(x1s,1);f=f*fs;
fxs=fft(x1s);ttp=abs(fxs)/10;%ttp=20*log10(ttp+1e-10);
subplot 528;;hold on;plot([4/3 4/3],[0 100],'k:','linewidth',1.5);plot([2 2],[0 100],':','color',[.3 .6 1],'linewidth',1.5)
plot(f,ttp,'k.-','linewidth',2,'markersize',16);
f=1:size(y1s,1);f=f-1;f=f/size(y1s,1);f=f*fs;
fxs=fft(y1s);ttp=abs(fxs)/10;%ttp=20*log10(ttp+1e-10);
hold on;plot(f,ttp,'.:','color',[.3 .6 1],'linewidth',2,'markersize',16)
xlim(([0.15 3.5]));ylim([0 35])
set(gca,'ytick',[0 35]);set(gca,'yticklabel',['0';'1'])
set(gca,'xtick',[0:5])
