clear;clc
OFFSET=1;

fs=200;
T=1/4;
t=1/fs:1/fs:T*4;t=t';
if OFFSET==1
    xs=OFFSET-cos(2*pi*t/T);
    xs=xs/2;
else
    xs=sin(2*pi*t/T);
end

for idx=1:20
    s1=[];s2=[];
    for ind=1:10
        rndv=[rand+0.1];
        %     s=[s; xs*[rand+0.1]];
        s1=[s1; xs*rndv];
        s2=[s2; xs*0+rndv];
    end

    s3=diff(s2);s3=[s3;0];
    s4=abs(s3);

    fxs1=abs(fft(s1));fxs1=fxs1/max(fxs1);%fxs1=20*log10(fxs1+1e-20);
    fxs2=abs(fft(s2));fxs2=fxs2/max(fxs2);%fxs2=20*log10(fxs2+1e-20);
    fxs3=abs(fft(s3));fxs3=fxs3/max(fxs3);%fxs3=20*log10(fxs3+1e-20);
    fxs4=abs(fft(s4));fxs4=fxs4/max(fxs4);%fxs4=20*log10(fxs4+1e-20);
    fxs1s(:,idx)=fxs1;
    fxs2s(:,idx)=fxs2;
    fxs3s(:,idx)=fxs3;
    fxs4s(:,idx)=fxs4;
end
fxs1=mean(fxs1s,2);
fxs2=mean(fxs2s,2);
fxs3=mean(fxs3s,2);
fxs4=mean(fxs4s,2);

%%
t=1:2000;t=t/fs;
figure
subplot 423
plot(t,s1,'k','linewidth',2);xlim([0 10]);set(gca,'box','off')
subplot 421
plot(t,s2,'k','linewidth',2);xlim([0 10]);set(gca,'box','off')
% subplot 425
% plot(s3,'k','linewidth',2);xlim([1 fs*10])
% subplot 427
% plot(s4,'k','linewidth',2);xlim([1 fs*10])

f=1:size(s1,1);f=f-1;f=f/size(s1,1);f=f*fs;
subplot 424
plot(f,fxs1,'k','linewidth',2);xlim([0.1 3.5]);%ylim([-60 6])
set(gca,'xtick',[0 1 2 3])
ylim([0 .15]);set(gca,'ytick',[0 .15]);set(gca,'yticklabel',['0';'1']);set(gca,'box','off')

subplot 422
plot(f,fxs2,'k','linewidth',2);xlim([0.1 3.5]);%ylim([-60 6])
set(gca,'xtick',[0 1 2 3])
ylim([0 .15]);set(gca,'ytick',[0 .15]);set(gca,'yticklabel',['0';'1']);set(gca,'box','off')
% subplot 426
% plot(f,fxs3,'k','linewidth',2);xlim([0 7]);%ylim([-60 6]+20)
% subplot 428
% plot(f,fxs4,'k','linewidth',2);xlim([0 7]);%ylim([-60 6]+20)


