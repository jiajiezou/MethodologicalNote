clear;clc;figure
% Figure 1A

fs=200;
T=.25;t=1/fs:1/fs:T;t=t';
xs=1-cos(2*pi*t/T);x1=xs/2;
x0=sin(2*pi*t/T);

T=.5;t=1/fs:1/fs:T;t=t';
ys=1-cos(2*pi*t/T);y1=ys/2;
y0=sin(2*pi*t/T);

T=.75;t=1/fs:1/fs:T;t=t';
zs=1-cos(2*pi*t/T);z1=zs/2;
z0=sin(2*pi*t/T);

t=1/fs:1/fs:1;


x1s=[z0;x0*0;];
y1s=[y0;y0*0;];
subplot 527;hold on;plot([.75 .75],[-1 1],'k:','linewidth',1.5);plot([.5 .5],[-1 1],':','color',[.3 .6 1],'linewidth',1.5);plot([0 1],[0 0],'k')
plot(t,x1s,'k','linewidth',2)
hold on;plot(t,y1s,':','color',[.3 .6 1],'linewidth',2)
set(gca,'xtick',[0 .25 .5 .75 1])

x1s=[x1s;x1s;x1s;x1s;x1s;x1s;x1s;x1s;x1s;x1s;]/8;y1s=[y1s;y1s;y1s;y1s;y1s;y1s;y1s;y1s;y1s;y1s;]/8;
f=1:size(x1s,1);f=f-1;f=f/size(x1s,1);f=f*fs;
fxs=fft(x1s);ttp=abs(fxs);%ttp=20*log10(ttp+1e-10);
subplot 528;;hold on;plot([4/3 4/3],[0 100],'k:','linewidth',1.5);plot([2 2],[0 100],':','color',[.3 .6 1],'linewidth',1.5)
plot(f,ttp,'k.-','linewidth',2,'markersize',16);
fxs=fft(y1s);ttp=abs(fxs);%ttp=20*log10(ttp+1e-10);
hold on;plot(f,ttp,'.:','color',[.3 .6 1],'linewidth',2,'markersize',16)
xlim([0.1 3.5]);ylim([0 100])
set(gca,'ytick',[0 100]);set(gca,'yticklabel',['0';'1'])
set(gca,'xtick',[0 1 2 3])

%:----------------------------------------------------

t=1/fs:1/fs:1;t=t';
x1s=exp(-t/0.25);
y1s=exp(-t/0.5);
subplot 521;hold on;plot([.75 .75],[0 1],'k:','linewidth',1.5);plot([.5 .5],[0 1],':','color',[.3 .6 1],'linewidth',1.5)
plot(t,x1s,'k','linewidth',2)
hold on;plot(t,y1s,':','color',[.3 .6 1],'linewidth',2);
set(gca,'xtick',[0 .25 .5 .75 1])

x1s=[x1s;x1s;x1s;x1s;x1s;x1s;x1s;x1s;x1s;x1s;]/8;y1s=[y1s;y1s;y1s;y1s;y1s;y1s;y1s;y1s;y1s;y1s;]/8;
f=1:size(x1s,1);f=f-1;f=f/size(x1s,1);f=f*fs;
fxs=fft(x1s);ttp=abs(fxs);%ttp=20*log10(ttp+1e-10);
subplot 522;hold on;plot([4/3 4/3],[0 100],'k:','linewidth',1.5);plot([2 2],[0 100],':','color',[.3 .6 1],'linewidth',1.5)
plot(f,ttp,'k.-','linewidth',2,'markersize',16);
fxs=fft(y1s);ttp=abs(fxs);%ttp=20*log10(ttp+1e-10);
hold on;plot(f,ttp,'.:','color',[.3 .6 1],'linewidth',2,'markersize',16)
xlim([0.1 3.5]);ylim([0 100])
set(gca,'ytick',[0 100]);set(gca,'yticklabel',['0';'1'])
set(gca,'xtick',[0 1 2 3])


x1s=[z1;x1*0;];
y1s=[y1;y1*0;];
subplot 525;hold on;plot([.75 .75],[0 1],'k:','linewidth',1.5);plot([.5 .5],[0 1],':','color',[.3 .6 1],'linewidth',1.5)
plot(t,x1s,'k','linewidth',2)
hold on;plot(t,y1s,':','color',[.3 .6 1],'linewidth',2)
set(gca,'xtick',[0 .25 .5 .75 1])

x1s=[x1s;x1s;x1s;x1s;x1s;x1s;x1s;x1s;x1s;x1s;]/8;y1s=[y1s;y1s;y1s;y1s;y1s;y1s;y1s;y1s;y1s;y1s;]/8;
f=1:size(x1s,1);f=f-1;f=f/size(x1s,1);f=f*fs;
fxs=fft(x1s);ttp=abs(fxs);%ttp=20*log10(ttp+1e-10);
subplot 526;;hold on;plot([4/3 4/3],[0 100],'k:','linewidth',1.5);plot([2 2],[0 100],':','color',[.3 .6 1],'linewidth',1.5)
plot(f,ttp,'k.-','linewidth',2,'markersize',16);
fxs=fft(y1s);ttp=abs(fxs);%ttp=20*log10(ttp+1e-10);
hold on;plot(f,ttp,'.:','color',[.3 .6 1],'linewidth',2,'markersize',16)
xlim([0.1 3.5]);ylim([0 100])
set(gca,'ytick',[0 100]);set(gca,'yticklabel',['0';'1'])
set(gca,'xtick',[0 1 2 3])
%% :-----------------------
t=1/fs:1/fs:.5;t=t';
y1s=[t;zeros(fs*0.5,1);]/.5;
t=1/fs:1/fs:.75;t=t';
x1s=[t;zeros(fs*0.25,1);]/.75;
t=1/fs:1/fs:1;t=t';
subplot 523;hold on;plot([.75 .75],[0 1],'k:','linewidth',1.5);plot([.5 .5],[0 1],':','color',[.3 .6 1],'linewidth',1.5)
plot(t,x1s,'k','linewidth',2)
hold on;plot(t,y1s,':','color',[.3 .6 1],'linewidth',2)
set(gca,'xtick',[0 .25 .5 .75 1])

x1s=[x1s;x1s;x1s;x1s;x1s;x1s;x1s;x1s;x1s;x1s;]/8;y1s=[y1s;y1s;y1s;y1s;y1s;y1s;y1s;y1s;y1s;y1s;]/8;
f=1:size(x1s,1);f=f-1;f=f/size(x1s,1);f=f*fs;
fxs=fft(x1s);ttp=abs(fxs);%ttp=20*log10(ttp+1e-10);
subplot 524;;hold on;plot([4/3 4/3],[0 100],'k:','linewidth',1.5);plot([2 2],[0 100],':','color',[.3 .6 1],'linewidth',1.5)
plot(f,ttp,'k.-','linewidth',2,'markersize',16);
fxs=fft(y1s);ttp=abs(fxs);%ttp=20*log10(ttp+1e-10);
hold on;plot(f,ttp,'.:','color',[.3 .6 1],'linewidth',2,'markersize',16)
xlim([0.1 3.5]);ylim([0 100])
set(gca,'ytick',[0 100]);set(gca,'yticklabel',['0';'1'])
set(gca,'xtick',[0 1 2 3])
