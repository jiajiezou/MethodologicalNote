clear;clc
OFFSET=1;

fs=200;
T=0.25;
t=1/fs:1/fs:T*8*120;t=t';
if OFFSET==1
    xs=OFFSET-cos(2*pi*t/T);
    xs=xs/2;
else
    xs=sin(2*pi*t/T);
end
n=randn(size(xs));
xs=xs*0+n;

for idx=1:50
    s1=[];s2=[];
    for ind=1:20
        s1=[s1 xs([1:fs*5]+(ind-1)*fs)];
%         s2=[s2; xs*0+rndv];
    end
    s1=mean(s1,2);

    fxs1=abs(fft(s1));fxs1=fxs1/max(fxs1);%fxs1=20*log10(fxs1+1e-20);
    fxs1s(:,idx)=fxs1;
end
fxs1=mean(fxs1s,2);


t=1:1000;t=t/fs;
figure
subplot(5,2,[3 5]+1)
plot(t,s1*1.5,'k','linewidth',2);xlim([0 5]);set(gca,'box','off')
% subplot 423
% plot(s2,'k','linewidth',2);xlim([1 fs*10])
% subplot 425
% plot(s3,'k','linewidth',2);xlim([1 fs*10])
% subplot 427
% plot(s4,'k','linewidth',2);xlim([1 fs*10])

f=1:size(s1,1);f=f-1;f=f/size(s1,1);f=f*fs;
subplot(5,2,[3 5]+5)
plot(f,fxs1,'k','linewidth',2);xlim([0.1 7/2]);;set(gca,'box','off')%ylim([-60 6])
% subplot 424
% plot(f,fxs2,'k','linewidth',2);xlim([0 7]);ylim([-60 6])
% subplot 426
% plot(f,fxs3,'k','linewidth',2);xlim([0 7]);ylim([-60 6]+20)
% subplot 428
% plot(f,fxs4,'k','linewidth',2);xlim([0 7]);ylim([-60 6]+20)

%%
clear xs
% figure
fs=200;
s=[zeros(1,fs*4.8-1) ones(1,1) zeros(1,fs*14-1)];
for ind=1:5
    xs(:,ind)=s([1:fs*5]+fs*ind-fs)+ind*1.2;
end
% 2:5
t=1:1000;t=t/fs;
subplot(5,2,[3:2:8])
plot(t,xs,'k','linewidth',2)
ylim([1 7.2])
xlim([0 5]);set(gca,'box','off')

subplot(5,2,9)
plot(t,sum(xs,2),'k','linewidth',2)
xlim([0 5])
ylim([17.9 19.5])
set(gca,'ytick',[18 19]);set(gca,'yticklabel',['0';'1']);set(gca,'box','off')

xs2=s(1:12*fs);
t=1:2400;t=t/fs;
subplot(5,2,1:2)
plot(t,xs2,'k','linewidth',2)
xlim([0 11.6])
set(gca,'xtick',[0:2:10]);set(gca,'box','off')
ylim([0 1.3])% xlim([0 5])
% ylim([17.9 19.5])
