clear;clc

fs=210;
T=1;
t=1/fs:1/fs:1;t=t';
figure;subplot 221;hold on
xT=sin(2*pi*t*3)*.7;%plot(xT,'k')
x1=sin(2*pi*t*1)*.7;plot(t,x1-1*2,'k','linewidth',2)
x2=sin(2*pi*t*2)*.7;plot(t,x2-2*2,'k','linewidth',2)
x3=sin(2*pi*t*4)*.7;plot(t,x3-3*2,'k','linewidth',2)
xS=[zeros(fs/3,1)-.8; zeros(fs/3,1)+.8; zeros(fs/3,1)+.2];
plot(t,xS,'k','linewidth',2)
ylim([-7.5 1.5]);%set(gca,'ytick',[0 .15]);
set(gca,'box','off');set(gca,'ytick',-100);

subplot 222;hold on
plot(t,x1.*xT-1*2,'k','linewidth',2);plot(t,t*0-2,'k')
plot(t,x2.*xT-2*2,'k','linewidth',2);plot(t,t*0-4,'k')
plot(t,x3.*xT-3*2,'k','linewidth',2);plot(t,t*0-6,'k')
plot(t,xS.*xT,'k','linewidth',2);plot(t,t*0,'k')
ylim([-7.5 1.5]);%set(gca,'ytick',[0 .15]);
set(gca,'box','off');set(gca,'ytick',-100);

xT'*[x1 x2 x3 xS]

subplot 223;hold on
x1=sin(2*pi*t*1.1)*.7;plot(t,x1-1*2,'k','linewidth',2)
x2=sin(2*pi*t*2.1)*.7;plot(t,x2-2*2,'k','linewidth',2)
x3=sin(2*pi*t*4.1)*.7;plot(t,x3-3*2,'k','linewidth',2)
xS=[1;0*[1:[fs/3-1]]';1;0*[1:[fs/3-1]]'/fs;1;0*[1:[fs/3-1]]'/fs];
xS=circshift(xS,fs/10);
plot(t,xS,'k','linewidth',2)
ylim([-7.5 1.5]);%set(gca,'ytick',[0 .15]);
set(gca,'box','off');set(gca,'ytick',-100);

subplot 224;hold on
plot(t,x1.*xT-1*2,'k','linewidth',2);plot(t,t*0-2,'k')
plot(t,x2.*xT-2*2,'k','linewidth',2);plot(t,t*0-4,'k')
plot(t,x3.*xT-3*2,'k','linewidth',2);plot(t,t*0-6,'k')
plot(t,xS.*xT,'k','linewidth',2);plot(t,t*0,'k')
ylim([-7.5 1.5]);%set(gca,'ytick',[0 .15]);
set(gca,'box','off');set(gca,'ytick',-100);

xT'*[x1 x2 x3 xS]

%%
figure
subplot 121;hold on
plot(t,xT,'k','linewidth',2)
ylim([-.8 .8]);%set(gca,'ytick',[0 .15]);
set(gca,'box','off');set(gca,'ytick',-100);

subplot 122;hold on
plot(t,xT.*xT,'k','linewidth',2);plot(t,t*0,'k')
ylim([-.1 .7]);%set(gca,'ytick',[0 .15]);
set(gca,'box','off');set(gca,'ytick',-100);

return
